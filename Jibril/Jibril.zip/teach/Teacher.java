package teach;

public class Teacher {
	public static void main (String args[]){
		
	}
	
}
